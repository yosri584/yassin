package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
public class utilisateurController {

    @Autowired
    private utilisateurService userService;

    @PostMapping("/signup")
    public User signup(@RequestParam User user) {
        return userService.signup( user);
    }

    @PostMapping("/signin")
    public boolean signin(@RequestParam String email, @RequestParam String password) {
        return userService.signin(email, password);
    }
}
